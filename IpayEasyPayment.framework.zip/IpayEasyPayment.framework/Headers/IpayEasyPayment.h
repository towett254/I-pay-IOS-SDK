//
//  IpayEasyPayment.h
//  IpayEasyPayment
//
//  Created by joshua kisee on 5/25/20.
//  Copyright © 2020 joshua kisee. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for IpayEasyPayment.
FOUNDATION_EXPORT double IpayEasyPaymentVersionNumber;

//! Project version string for IpayEasyPayment.
FOUNDATION_EXPORT const unsigned char IpayEasyPaymentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IpayEasyPayment/PublicHeader.h>


